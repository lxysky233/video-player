const SOURCE_NAME = "无尽影视";
const USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36";
const MIRRORS = [];

const apiBase = "https://api.wujinapi.com/api.php/provide/vod/";
const pageSize = 20;
const cacheKey = "categories-v1";
const cacheTTL = 6 * 60 * 60 * 1000;

function text(url) {
  const response = host.fetchText({ url: url, userAgent: USER_AGENT, mirrors: MIRRORS });
  return response.body || "";
}

function parseJson(body) {
  const trimmed = (body || "").trim();
  if (trimmed === "") {
    throw new Error("站点返回了空响应");
  }
  try {
    return JSON.parse(trimmed);
  } catch (error) {
    throw new Error("站点返回的内容不是有效 JSON");
  }
}

function request(params) {
  const query = Object.keys(params)
    .map(function (key) { return key + "=" + encodeURIComponent(params[key]); })
    .join("&");
  return parseJson(text(apiBase + "?" + query));
}

function stringOf(value) {
  return value === null || value === undefined ? "" : String(value).trim();
}

function intOf(value, fallback) {
  const parsed = parseInt(stringOf(value), 10);
  return isNaN(parsed) ? fallback : parsed;
}

function splitList(value) {
  const list = [];
  const parts = stringOf(value).split(",");
  for (let index = 0; index < parts.length; index++) {
    const name = parts[index].trim();
    if (name !== "" && list.indexOf(name) < 0) {
      list.push(name);
    }
  }
  return list;
}

function drama(item) {
  const sourceId = stringOf(item.vod_id);
  const title = stringOf(item.vod_name);
  const kind = stringOf(item.vod_class) || stringOf(item.type_name);
  const remark = stringOf(item.vod_remarks);
  const total = intOf(item.vod_total, 0) || intOf(item.vod_episode, 0);
  return {
    id: host.dramaId(sourceId),
    source: host.source,
    sourceId: sourceId,
    title: title,
    name: title,
    desc: stringOf(item.vod_blurb) || stringOf(item.vod_content).replace(/<[^>]+>/g, ""),
    intro: stringOf(item.vod_content).replace(/<[^>]+>/g, ""),
    cover: stringOf(item.vod_pic),
    remark: remark,
    tags: splitList(kind),
    typeName: kind,
    channelName: kind,
    score: stringOf(item.vod_score),
    totalEpisode: total > 0 ? total : undefined,
    onlineDate: stringOf(item.vod_pubdate),
  };
}

function pageOf(result) {
  const list = result.list || [];
  const items = [];
  for (let index = 0; index < list.length; index++) {
    const entry = drama(list[index]);
    if (entry.sourceId !== "" && entry.title !== "") {
      items.push(entry);
    }
  }
  const page = intOf(result.page, 1);
  const pages = intOf(result.pagecount, page);
  return { items: items, hasMore: list.length >= pageSize && page < pages };
}

function categoriesOf(result) {
  const classes = result.class || [];
  const list = [];
  for (let index = 0; index < classes.length; index++) {
    const id = stringOf(classes[index].type_id);
    const name = stringOf(classes[index].type_name);
    if (id !== "" && name !== "") {
      list.push({ id: id, name: name });
    }
  }
  return list;
}

function cachedCategories() {
  const cached = host.cacheGet(cacheKey);
  if (cached && cached.length) {
    try {
      const list = JSON.parse(cached);
      if (list.length) {
        return list;
      }
    } catch (error) {
      /* 缓存损坏时重新抓取 */
    }
  }
  const list = categoriesOf(request({ ac: "list" }));
  host.cacheSet(cacheKey, JSON.stringify(list), cacheTTL);
  return list;
}

function episodes(sourceId) {
  const result = request({ ac: "detail", ids: sourceId });
  const list = result.list || [];
  if (!list.length) {
    throw new Error("站点没有返回这部剧的信息");
  }
  const item = list[0];
  const from = stringOf(item.vod_play_from).split("$$$");
  const urls = stringOf(item.vod_play_url).split("$$$");
  let best = -1;
  for (let index = 0; index < urls.length && index < from.length; index++) {
    if (urls[index].indexOf("m3u8") >= 0) {
      best = index;
      break;
    }
  }
  if (best < 0) {
    best = 0;
  }
  const raw = urls[best] || urls[0] || "";
  const chapters = [];
  const parts = raw.split("#");
  let order = 0;
  for (let index = 0; index < parts.length; index++) {
    const part = parts[index].trim();
    if (part === "") {
      continue;
    }
    const cut = part.indexOf("$");
    const label = cut >= 0 ? part.slice(0, cut) : "";
    const address = cut >= 0 ? part.slice(cut + 1) : part;
    if (address.trim() === "") {
      continue;
    }
    order += 1;
    chapters.push({ label: label, address: address.trim(), order: order });
  }
  if (!chapters.length) {
    throw new Error("站点没有返回可播放的分集");
  }
  return { item: item, chapters: chapters };
}

module.exports = {
  validCategory(category) {
    if (category === "" || category === undefined || category === null) {
      return true;
    }
    const list = cachedCategories();
    for (let index = 0; index < list.length; index++) {
      if (list[index].id === String(category)) {
        return true;
      }
    }
    return false;
  },

  categories() {
    return cachedCategories();
  },

  catalogPage(page, category) {
    const params = { ac: "detail", pg: page };
    if (category !== "" && category !== undefined && category !== null) {
      params.t = String(category);
    }
    return pageOf(request(params));
  },

  search(page, query) {
    const keyword = (query || "").trim();
    if (keyword === "") {
      return { items: [], hasMore: false };
    }
    return pageOf(request({ ac: "detail", wd: keyword, pg: page }));
  },

  detail(sourceId) {
    const resolved = episodes(sourceId);
    const entry = drama(resolved.item);
    const chapters = [];
    for (let index = 0; index < resolved.chapters.length; index++) {
      const chapter = resolved.chapters[index];
      chapters.push({
        id: host.chapterId(sourceId, String(chapter.order)),
        source: host.source,
        title: chapter.label || "第 " + chapter.order + " 集",
        currentEpisode: chapter.order,
      });
    }
    entry.totalEpisode = chapters.length;
    return { drama: entry, chapters: chapters };
  },

  resolveMedia(task) {
    const prefix = host.source + ":";
    const dramaId = task.dramaId.indexOf(prefix) === 0 ? task.dramaId.slice(prefix.length) : "";
    const chapterPrefix = host.chapterId(dramaId, "");
    if (dramaId === "" || task.chapter.id.indexOf(chapterPrefix) !== 0) {
      throw new Error("分集信息无效，请刷新详情");
    }
    const order = intOf(task.chapter.id.slice(chapterPrefix.length), 0);
    const resolved = episodes(dramaId);
    if (order < 1 || order > resolved.chapters.length) {
      throw new Error("这一集不在站点返回的分集列表里");
    }
    const address = resolved.chapters[order - 1].address;
    const media = { url: address, referer: apiBase };
    return address.indexOf(".m3u8") >= 0 ? host.prepareWebMedia(media, SOURCE_NAME) : media;
  },
};
